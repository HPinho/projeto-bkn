/* Extracts the studio's vendored icons from the npm packages installed as
   devDeps (real data, not hand-copied) — same pattern as
   playground/extract-vendor-icons.mjs in the library repo:
   - Heroicons (MIT) — heroicons/24/outline/*.svg
   - Tabler Icons (MIT) — @tabler/icons/tabler-nodes-outline.json (IconNode)
   Labels are chosen for searchability (the studio filters on label), so a
   universal glyph gets its universal name (search, mail, download…) even when
   the pack calls it something else (magnifying-glass, envelope,
   arrow-down-tray…). Regenerate after changing the selection:
     bun scripts/extract-vendor-icons.mjs  (from website/) */

import { readFileSync, writeFileSync } from "node:fs";

/* label → source file in heroicons/24/outline. Universal glyphs first, then
   the pack's distinctive voice. */
const HEROICONS_PICK = {
  home: "home",
  search: "magnifying-glass",
  user: "user",
  bell: "bell",
  heart: "heart",
  star: "star",
  trash: "trash",
  edit: "pencil-square",
  mail: "envelope",
  calendar: "calendar",
  clock: "clock",
  folder: "folder",
  bookmark: "bookmark",
  chat: "chat-bubble-oval-left",
  "thumbs-up": "hand-thumb-up",
  "map-pin": "map-pin",
  globe: "globe-alt",
  lock: "lock-closed",
  eye: "eye",
  download: "arrow-down-tray",
  upload: "arrow-up-tray",
  share: "share",
  link: "link",
  phone: "phone",
  photo: "photo",
  play: "play",
  music: "musical-note",
  filter: "funnel",
  "credit-card": "credit-card",
  "shopping-cart": "shopping-cart",
  gift: "gift",
  bolt: "bolt",
  sun: "sun",
  moon: "moon",
  cloud: "cloud",
  camera: "camera",
  cog: "cog-6-tooth",
  scissors: "scissors",
  wifi: "wifi",
  sparkles: "sparkles",
  fire: "fire",
  rocket: "rocket-launch",
  beaker: "beaker",
  "light-bulb": "light-bulb",
  puzzle: "puzzle-piece",
  "academic-cap": "academic-cap",
  key: "key",
  shield: "shield-check",
  smile: "face-smile",
  send: "paper-airplane",
  paperclip: "paper-clip",
  terminal: "command-line",
  code: "code-bracket",
  trophy: "trophy",
  cake: "cake",
  /* Showcase pairs (app/showcase): every recipe endpoint must exist in the
     three libraries so the library selector swaps them 1:1. */
  copy: "document-duplicate",
  check: "check",
  x: "x-mark",
  "eye-off": "eye-slash",
  pause: "pause",
  "folder-open": "folder-open",
  volume: "speaker-wave",
  "volume-x": "speaker-x-mark",
};

/* Tabler names are already friendly; the search matches substrings, so
   mood-smile is found by "smile". Universal first, then the fun ones the
   other packs don't have. An entry is a name, or [label, name] when the
   universal label differs from Tabler's (player-play → play). */
const TABLER_PICK = [
  "home",
  "search",
  "settings",
  "user",
  "bell",
  "heart",
  "star",
  "trash",
  "pencil",
  "download",
  "upload",
  "share",
  "link",
  "phone",
  "photo",
  "music",
  "filter",
  "map-pin",
  "key",
  "gift",
  "database",
  "cpu",
  "wifi",
  "coffee",
  "flame",
  "flask",
  "mood-smile",
  "cake",
  "diamond",
  "crown",
  "anchor",
  "feather",
  "umbrella",
  "snowflake",
  "butterfly",
  "fish",
  "paw",
  "pizza",
  "plant",
  "skull",
  "sword",
  "wand",
  "alien",
  "robot",
  "meteor",
  "campfire",
  "balloon",
  "puzzle",
  "atom",
  "palette",
  "cat",
  "ghost",
  "planet",
  "rocket",
  "bolt",
  "brand-github",
  "bike",
  "moon-stars",
  /* Showcase pairs (app/showcase) — see the note on HEROICONS_PICK. */
  "copy",
  "check",
  "x",
  "eye",
  "eye-off",
  "sun",
  "moon",
  "folder-open",
  "volume",
  ["volume-x", "volume-off"],
  ["play", "player-play"],
  ["pause", "player-pause"],
];

/* [label, tablerName] for every entry. */
const TABLER_ENTRIES = TABLER_PICK.map((e) =>
  Array.isArray(e) ? e : [e, e],
);

/* Presentation attrs are set at the <svg> level by the site (stroke, caps,
   joins) — only geometry survives into the vendored IconNode. */
const DROP_ATTRS = new Set([
  "fill",
  "stroke",
  "stroke-width",
  "stroke-linecap",
  "stroke-linejoin",
  "fill-rule",
  "clip-rule",
]);

/* Heroicons outline contents are flat sequences of elements with quoted
   attributes — a regex is enough (no nesting, no text). */
const parseContents = (s) => {
  const inner = s.replace(/<svg[^>]*>/, "").replace(/<\/svg>\s*$/, "");
  const nodes = [];
  for (const m of inner.matchAll(/<([a-z]+)((?:\s+[\w-]+="[^"]*")*)\s*\/?>/g)) {
    const attrs = {};
    for (const a of m[2].matchAll(/([\w-]+)="([^"]*)"/g)) {
      if (!DROP_ATTRS.has(a[1])) attrs[a[1]] = a[2];
    }
    nodes.push([m[1], attrs]);
  }
  return nodes;
};

const heroicon = (file) => {
  try {
    return parseContents(
      readFileSync(`node_modules/heroicons/24/outline/${file}.svg`, "utf8"),
    );
  } catch {
    return null;
  }
};

const tabler = JSON.parse(
  readFileSync("node_modules/@tabler/icons/tabler-nodes-outline.json", "utf8"),
);

const missing = [
  ...Object.values(HEROICONS_PICK)
    .filter((f) => heroicon(f) === null)
    .map((f) => `heroicons:${f}`),
  ...TABLER_ENTRIES.filter(([, n]) => !tabler[n]).map(([, n]) => `tabler:${n}`),
];
if (missing.length) {
  console.error("Not present in the packages:", missing.join(", "));
  process.exit(1);
}

const version = (pkg) =>
  JSON.parse(readFileSync(`node_modules/${pkg}/package.json`, "utf8")).version;

const entries = (pairs) =>
  pairs.map(([label, node]) => `  "${label}": ${JSON.stringify(node)},`).join("\n");

const out = `/* GENERATED by scripts/extract-vendor-icons.mjs — do not edit by hand.
   Icon data for the studio, extracted from the devDep packages:
   Heroicons v${version("heroicons")} (24/outline, MIT, Tailwind Labs) ·
   Tabler Icons v${version("@tabler/icons")} (outline, MIT).
   Neither is a dependency of the site: morphicons consumes structural
   IconNode, and only geometry attributes are vendored. */

import type { IconNode } from "morphicons";

export const HEROICONS: Record<string, IconNode> = {
${entries(Object.entries(HEROICONS_PICK).map(([label, f]) => [label, heroicon(f)]))}
};

export const TABLER: Record<string, IconNode> = {
${entries(TABLER_ENTRIES.map(([label, n]) => [label, tabler[n]]))}
};
`;

writeFileSync("lib/vendor-icons.ts", out);
console.log(
  `OK → lib/vendor-icons.ts (${Object.keys(HEROICONS_PICK).length} heroicons, ${TABLER_PICK.length} tabler)`,
);
